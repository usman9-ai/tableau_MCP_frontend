import { Routes, Route } from 'react-router-dom';
import ChatArea from './components/ChatArea';
import Header from './components/Header';
import Login from './pages/LoginPage';

function HomePage() {
  return (
    <div className="flex flex-col h-screen bg-primary text-text-primary overflow-hidden">
      <Header />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <ChatArea />
      </div>
    </div>
  );
}

function App() {
  return (
    <Routes>
      <Route path="/home" element={<HomePage />} />
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<Login />} />
    </Routes>
  );
}

export default App;
