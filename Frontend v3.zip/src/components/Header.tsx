import React from 'react';
import { useStore } from '../store/useStore';

const Header: React.FC = () => {
  const { currentConversation, createConversation } = useStore();

  return (
    <header className="h-16 border-b border-border bg-secondary flex items-center justify-between px-6 backdrop-blur-sm sticky top-0 z-10 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-accent to-accent-hover flex items-center justify-center shadow-sm text-white font-semibold">
          UBL
        </div>
        <div>
          <p className="text-sm font-semibold text-text-primary">UBL Tableau Analytics</p>
          <p className="text-xs text-text-secondary">{currentConversation?.title || 'New conversation'}</p>
        </div>
      </div>

      <button
        onClick={createConversation}
        className="py-2.5 px-4 bg-accent hover:bg-accent-hover rounded-xl font-medium transition-all duration-200 flex items-center justify-center gap-2 shadow-sm hover:shadow-md transform hover:scale-[1.02] active:scale-[0.98] text-white"
      >
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
        </svg>
        <span>New Chat</span>
      </button>
    </header>
  );
};

export default Header;
