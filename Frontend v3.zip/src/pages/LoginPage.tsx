import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FaEnvelope, FaLock } from 'react-icons/fa';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import loginImage from '../assets/images/login-image.jpg';
import logo from '../assets/images/ubl-logo.png';
import { loginRequest } from '../services/authService';
import { useStore } from '../store/useStore';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<{ email?: string; password?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const { setAuth } = useStore();

  const validateField = (name: 'email' | 'password', value: string) => {
    let error = '';
    switch (name) {
      case 'email':
        if (!value) {
          error = 'Email address is required.';
        } else if (!/\S+@\S+\.\S+/.test(value)) {
          error = 'Please enter a valid email address.';
        }
        break;
      case 'password':
        if (!value) {
          error = 'Password is required.';
        }
        break;
      default:
        break;
    }
    setErrors((prevErrors) => ({ ...prevErrors, [name]: error }));
    return !error;
  };

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const isEmailValid = validateField('email', email);
    const isPasswordValid = validateField('password', password);

    if (!isEmailValid || !isPasswordValid) {
      return;
    }

    try {
      setIsSubmitting(true);
      const response = await loginRequest(email, password);
      setAuth(response.access_token, response.user);

      toast.success(`Welcome back, ${response.user.name}!`, {
        position: 'top-center',
        autoClose: 1500,
      });

      setTimeout(() => {
        navigate('/home');
      }, 1500);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Login failed. Please try again.';
      toast.error(message, {
        position: 'top-center',
        autoClose: 3000,
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-primary text-text-primary">
      <img
        src={loginImage}
        alt="UBL login background"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-black/55 backdrop-blur-sm" />

      <div className="relative z-10 flex min-h-screen items-center justify-center px-4 py-12">
        <div className="w-full max-w-md rounded-3xl border border-border-light bg-secondary/95 p-8 shadow-2xl shadow-black/10 backdrop-blur">
          <div className="flex flex-col items-center text-center">
            <img src={logo} alt="UBL Logo" className="h-16 w-auto" />
            <h2 className="mt-6 text-2xl font-semibold text-text-primary">Welcome back</h2>
            <p className="mt-2 text-sm text-text-secondary">
              Sign in with your corporate credentials to continue.
            </p>
          </div>

          <form onSubmit={handleLogin} noValidate className="mt-8 space-y-5">
            <div>
              <label htmlFor="email" className="mb-2 block text-sm font-medium text-text-secondary">
                Email address
              </label>
              <div className="relative">
                <FaEnvelope className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary" />
                <input
                  id="email"
                  type="email"
                  className={`w-full rounded-2xl border bg-primary/40 py-3 pl-12 pr-4 text-sm text-text-primary shadow-sm outline-none transition-all focus:bg-primary/50 focus:shadow-md focus:ring-2 ${errors.email
                      ? 'border-red-500 ring-red-100'
                      : 'border-border ring-accent/20 focus:border-accent'
                    }`}
                  placeholder="name@ubl.com.pk"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (errors.email) validateField('email', e.target.value);
                  }}
                  onBlur={() => validateField('email', email)}
                  required
                />
              </div>
              {errors.email && (
                <p className="mt-2 text-sm font-medium text-red-500">{errors.email}</p>
              )}
            </div>

            <div>
              <label htmlFor="password" className="mb-2 block text-sm font-medium text-text-secondary">
                Password
              </label>
              <div className="relative">
                <FaLock className="absolute left-4 top-1/2 -translate-y-1/2 text-text-secondary" />
                <input
                  id="password"
                  type="password"
                  className={`w-full rounded-2xl border bg-primary/40 py-3 pl-12 pr-4 text-sm text-text-primary shadow-sm outline-none transition-all focus:bg-primary/50 focus:shadow-md focus:ring-2 ${errors.password
                      ? 'border-red-500 ring-red-100'
                      : 'border-border ring-accent/20 focus:border-accent'
                    }`}
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errors.password) validateField('password', e.target.value);
                  }}
                  onBlur={() => validateField('password', password)}
                  required
                />
              </div>
              {errors.password && (
                <p className="mt-2 text-sm font-medium text-red-500">{errors.password}</p>
              )}
            </div>

            <button
              type="submit"
              className="mt-2 w-full rounded-2xl bg-accent py-3 text-sm font-semibold text-white transition-all hover:bg-accent-hover hover:shadow-lg disabled:cursor-not-allowed disabled:opacity-60"
              disabled={!email || !password || isSubmitting}
            >
              {isSubmitting ? 'Logging in...' : 'Log in'}
            </button>
          </form>
        </div>
      </div>
      <ToastContainer
        position="top-center"
        hideProgressBar
        toastClassName={() =>
          'relative flex items-center justify-between gap-3 overflow-hidden rounded-2xl border border-border bg-secondary px-4 py-3 text-sm font-medium text-text-primary shadow-lg shadow-black/10'
        }
        className={() => 'flex-1 text-left'}
      />
    </div>
  );
};

export default Login;
