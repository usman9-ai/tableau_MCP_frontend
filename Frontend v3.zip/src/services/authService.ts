const LOGIN_URL =
  import.meta.env.VITE_AUTH_LOGIN_URL ||
  'https://tableau-mcp-backend-epc3ggegardrf7er.uaenorth-01.azurewebsites.net/auth/login';

export interface LoginResponse {
  access_token: string;
  token_type: string;
  user: {
    id: number;
    email: string;
    name: string;
  };
}

export async function loginRequest(email: string, password: string): Promise<LoginResponse> {
  const response = await fetch(LOGIN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password }),
  });

  if (!response.ok) {
    const errorBody = await response.text();
    let message = 'Unable to login. Please try again.';

    try {
      const parsed = JSON.parse(errorBody);
      message = parsed.detail || parsed.message || message;
    } catch {
      if (errorBody) {
        message = errorBody;
      }
    }

    throw new Error(message);
  }

  return response.json();
}
