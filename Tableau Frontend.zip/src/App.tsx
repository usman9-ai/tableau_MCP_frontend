import { Routes, Route, Navigate } from 'react-router-dom';
import ChatArea from './components/ChatArea';
import Header from './components/Header';
import Login from './pages/LoginPage';
import { useStore } from './store/useStore';

function HomePage() {
  return (
    <div className="flex flex-col h-screen bg-primary text-text-primary overflow-hidden">
      <Header />
      <div className="flex-1 flex flex-col overflow-hidden min-h-0">
        <ChatArea />
      </div>
    </div>
  );
}

function ProtectedRoute({ element }: { element: React.ReactNode }) {
  const { accessToken } = useStore();

  if (!accessToken) {
    return <Navigate to="/login" replace />;
  }

  return element;
}

function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/home" element={<ProtectedRoute element={<HomePage />} />} />
      <Route path="/" element={<Navigate to="/home" replace />} />
    </Routes>
  );
}

export default App;
