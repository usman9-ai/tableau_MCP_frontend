interface User {
  email: string;
  password: string;
  role: 'admin' | 'user' | 'viewer';
  name: string;
}

export interface LoginResponse {
  access_token: string;
  token_type: string;
  user: {
    id: number;
    email: string;
    name: string;
    role: 'admin' | 'user' | 'viewer';
  };
}

let usersCache: User[] | null = null;

async function loadUsers(): Promise<User[]> {
  if (usersCache) {
    return usersCache;
  }

  try {
    const response = await fetch('/users.json');
    if (!response.ok) {
      throw new Error('Failed to load users');
    }
    usersCache = await response.json();
    return usersCache;
  } catch (error) {
    console.error('Error loading users:', error);
    throw new Error('Failed to load user database');
  }
}

export async function loginRequest(email: string, password: string): Promise<LoginResponse> {
  // Client-side only validation - no backend call
  const users = await loadUsers();

  const user = users.find((u) => u.email === email && u.password === password);

  if (!user) {
    throw new Error('Invalid email or password.');
  }

  // Generate a simple token (in a real app, this would come from backend)
  const token = btoa(`${email}:${Date.now()}`);

  return Promise.resolve({
    access_token: token,
    token_type: 'bearer',
    user: {
      id: users.indexOf(user) + 1,
      email: user.email,
      name: user.name,
      role: user.role,
    },
  });
}