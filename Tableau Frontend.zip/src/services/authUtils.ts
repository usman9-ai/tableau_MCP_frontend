import { useStore } from '../store/useStore';

export function isAuthenticated(): boolean {
  const { accessToken, user } = useStore.getState();
  return !!accessToken && !!user;
}

export function getCurrentUser() {
  const { user } = useStore.getState();
  return user;
}

export function logout(): void {
  const { clearAuth } = useStore.getState();
  clearAuth();
}

export function getAuthToken(): string | null {
  const { accessToken } = useStore.getState();
  return accessToken;
}

export function hasRole(role: 'admin' | 'user' | 'viewer'): boolean {
  const user = getCurrentUser();
  return user?.role === role;
}

export function hasAnyRole(...roles: Array<'admin' | 'user' | 'viewer'>): boolean {
  const user = getCurrentUser();
  return user ? roles.includes(user.role) : false;
}
