import { STATIC_CONVERSATION_ID } from '../store/useStore';

const API_BASE_URL =
  import.meta.env.VITE_API_URL as string;

export interface ChatMessage {
  message: string;
  conversation_id?: string;
}

export interface ThinkingStep {
  title: string;
  content: string;
  status: 'in-progress' | 'complete' | 'error';
}

export interface ChatResponse {
  response: string;
  conversation_id: string;
  thinking?: ThinkingStep[];
}

export interface HealthResponse {
  status: string;
  mcp_connected: boolean;
  active_conversations: number;
}

export interface StreamChunk {
  type: 'thinking_step' | 'thinking_step_update' | 'thinking_step_complete' | 'content' | 'done' | 'error';
  step?: ThinkingStep;
  content?: string;
  conversation_id?: string;
}

export type StreamCallback = (chunk: StreamChunk) => void;

export class MCPClient {
  private baseUrl: string;

  constructor(baseUrl: string = API_BASE_URL) {
    this.baseUrl = baseUrl;
  }

  async sendMessageStream(
    message: string, 
    conversationId: string | undefined,
    isRegenerate: boolean = false,
    onChunk: StreamCallback
  ): Promise<void> {
    const response = await fetch(`${this.baseUrl}/api/chat/stream`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ 
        message, 
        conversation_id: conversationId || STATIC_CONVERSATION_ID,
        is_regenerate: isRegenerate
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`API error (${response.status}): ${error}`);
    }

    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error('Response body is not readable');
    }

    const decoder = new TextDecoder();
    let buffer = '';

    try {
      while (true) {
        const { done, value } = await reader.read();
        
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        
        // Process complete SSE messages
        const lines = buffer.split('\n\n');
        buffer = lines.pop() || ''; // Keep incomplete message in buffer

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            try {
              const chunk: StreamChunk = JSON.parse(data);
              onChunk(chunk);
            } catch (e) {
              console.error('Failed to parse SSE data:', data, e);
            }
          }
        }
      }
    } finally {
      reader.releaseLock();
    }
  }

  async sendMessage(message: string, conversationId?: string): Promise<ChatResponse> {
    const response = await fetch(`${this.baseUrl}/api/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message,
        conversation_id: conversationId || STATIC_CONVERSATION_ID,
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      throw new Error(`API error (${response.status}): ${error}`);
    }

    return response.json();
  }

  async checkHealth(): Promise<HealthResponse> {
    const response = await fetch(`${this.baseUrl}/api/health`);
    
    if (!response.ok) {
      throw new Error(`Health check failed: ${response.status}`);
    }
    
    return response.json();
  }

  async deleteConversation(conversationId: string = STATIC_CONVERSATION_ID): Promise<{ status: string; conversation_id: string }> {
    const response = await fetch(`${this.baseUrl}/api/conversation/${conversationId}`, {
      method: 'DELETE',
    });

    if (!response.ok) {
      throw new Error(`Failed to delete conversation: ${response.status}`);
    }

    return response.json();
  }
}

export const mcpClient = new MCPClient();